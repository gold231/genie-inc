<template>
  <div class="row p-3">
    <div class="col-lg-2 col-md-12 px-0 border-dash items ">
      <div class="items">
        <img class="float-left" src="../assets/img/ajouter.png" width="97">   
      </div>
      <p class="font-weight-bold mb-0 mr-1">Ajouter une offre d’emploi</p>
    </div>
    <b-row class="col-lg-5 col-md-12 items">
      <b-col v-b-modal.modal-oups class="items">
        <div class="shadow float-left">
          <img src="../assets/img/Nouvelles_candidatures.png" width="97">
        </div>
        <p class="ml-1 mb-0"><span style="color: red;">14</span> nouvelles candidatures</p>
      </b-col>
      <b-col v-b-modal.modal-oups class="items">
        <div class="shadow float-left">
          <img src="../assets/img/offres.png" width="97">
        </div>
        <p class="ml-1 mb-0"><span style="color: red;">8</span> Offres actives</p>
      </b-col>
    </b-row>
    <b-modal id="modal-oups" hide-footer hide-header>
      <div class="text-center">
        <h4>Oups,</h4>
        <h4><span style="color: red;"> Ceci n’est pas un bouton,</span></h4> 
        <h4>Svp, me le mentionner si vous avez cliquer ici.</h4>
      </div>
    </b-modal>
    <b-row class="col-lg-5 col-md-12 items">
      <b-col>
        <div class="shadow float-left lefttab tab-width">
        </div>
        <p class="mt-3 mb-0">PHASE 2</p>
        <p style="color: #7c7c7c;"> Statistiques du recruteur</p>
      </b-col>
      <b-col>
        <div class="shadow float-left">
          <img src="../assets/img/offres.png" width="97">
        </div>
        <p class="mt-3 mb-0">PHASE 2</p>
        <p style="color: #7c7c7c;">+ Page statistique</p>
      </b-col>
    </b-row>
  </div>
</template>

<script>
export default {
  name: 'Toptab'
}
</script>

<style lang="scss" scoped>
.lefttab {
  height: 97px;
  width: 97px;
}
</style>